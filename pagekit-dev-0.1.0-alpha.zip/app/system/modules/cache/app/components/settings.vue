<template>
    <div>
        <div class="uk-margin uk-flex uk-flex-middle uk-flex-between uk-flex-wrap">
            <div>
                <h2 class="uk-h3 uk-margin-remove">
                    {{ 'Cache' | trans }}
                </h2>
            </div>
            <div class="uk-margin-small">
                <button class="uk-button uk-button-primary" type="submit">
                    {{ 'Save' | trans }}
                </button>
            </div>
        </div>

        <div class="uk-margin">
            <label class="uk-form-label">{{ 'Cache' | trans }}</label>
            <div class="uk-form-controls uk-form-controls-text">
                <p v-for="(cache, key) in caches" :key="key" class="uk-margin-small">
                    <label><input v-model="moduleConfig.caches.cache.storage" class="uk-radio" type="radio" :value="key" :disabled="!cache.supported"> {{ cache.name }}</label>
                </p>
            </div>
        </div>

        <div class="uk-margin">
            <label class="uk-form-label">{{ 'Developer' | trans }}</label>
            <div class="uk-form-controls uk-form-controls-text">
                <p class="uk-margin-small">
                    <label><input v-model="moduleConfig.nocache" class="uk-checkbox" type="checkbox" value="1"> {{ 'Disable cache' | trans }}</label>
                </p>
                <p>
                    <button class="uk-button uk-button-primary" type="button" @click.prevent="open">
                        {{ 'Clear Cache' | trans }}
                    </button>
                </p>
            </div>
        </div>

        <v-modal ref="modal">
            <form class="uk-form-stacked">
                <div class="uk-modal-header">
                    <h2 class="uk-h4">
                        {{ 'Select Cache to Clear' | trans }}
                    </h2>
                </div>

                <div class="uk-modal-body">
                    <div class="uk-margin">
                        <p class="uk-margin-small">
                            <label><input v-model="cache.cache" class="uk-checkbox" type="checkbox"> {{ 'System Cache' | trans }}</label>
                        </p>

                        <p class="uk-margin-small">
                            <label><input v-model="cache.temp" class="uk-checkbox" type="checkbox"> {{ 'Temporary Files' | trans }}</label>
                        </p>
                    </div>
                </div>

                <div class="uk-modal-footer uk-text-right">
                    <button class="uk-button uk-button-text uk-margin-right uk-modal-close" type="button">
                        {{ 'Cancel' | trans }}
                    </button>
                    <button class="uk-button uk-button-primary" @click.prevent="clear">
                        {{ 'Clear' | trans }}
                    </button>
                </div>
            </form>
        </v-modal>
    </div>
</template>

<script>

import SettingsMixin from '@system/modules/settings/app/mixins/settings-mixin';

const Cache = {

    mixins: [SettingsMixin, Theme.Mixins.Helper],

    section: {
        label: 'Cache',
        icon: 'bolt',
        priority: 30
    },

    data() {
        return {
            caches: window.$caches,
            cache: {}
        };
    },

    theme: {
        hideEls() {
            return this.$el.querySelectorAll('.uk-button-primary');
        },
        elements() {
            const vm = this;

            return {
                clearcache: {
                    scope: 'topmenu-left',
                    type: 'button',
                    caption: 'Clear Cache',
                    class: 'uk-button tm-button-success',
                    on: { click: () => vm.open() },
                    priority: 0,
                    vif: () => vm.$theme.getActiveTab('leftTab', true),
                    watch: () => vm.$theme.getActiveTab('leftTab')
                }
            };
        }
    },

    methods: {

        open() {
            this.$set(this, 'cache', { cache: true });
            this.$refs.modal.open();
        },

        clear() {
            this.$http.post('admin/system/cache/clear', { caches: this.cache }).then(function () {
                this.$notify(this.$trans('Cache cleared.'));
            });

            this.$refs.modal.close();
        }

    }

};

export default Cache;

window.Settings.components['system-cache'] = Cache;

</script>
